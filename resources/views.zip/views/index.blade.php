@extends('Layout.layout')
@section('title', 'Beranda')
@section('content')
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <!-- <ol class="carousel-indicators" id="hero-carousel-indicators"></ol> -->

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(assets/aset/baner/img1.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Selamat Datang di <span>SMKBM</span></h2>
              <p class="animate__animated animate__fadeInUp">"Tidak ada anak tidak bisa sekolah karena biaya"</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Selengkapnya..</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-2.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Teknik Komputer & Jaringan</h2>
              <!--<p class="animate__animated animate__fadeInUp text-truncate">Teknik Komputer Jaringan (TKJ) adalah ilmu berbasis Teknologi Informasi dan Komunikasi terkait kemampuan algoritma, dan pemrograman komputer, perakitan komputer, perakitan jaringan komputer, dan pengoperasian perangkat lunak, dan internet. Teknik komputer, dan jaringan juga membutuhkan pemahaman di bidang teknik listrik, dan ilmu komputer sehingga mampu mengembangkan, dan mengintegrasikan perangkat lunak, dan perangkat keras.</p>-->
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Selengkapnya</a>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/slide/slide-3.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Desain Komunikasi Visual</h2>
              <!--<p class="animate__animated animate__fadeInUp text-truncate">Desain Komunikasi Visual (DKV) adalah cabang ilmu desain yang mempelajari konsep komunikasi dan ungkapan kreatif, teknik dan media dengan memanfaatkan elemen-elemen visual ataupun rupa untuk menyampaikan pesan untuk tujuan tertentu (tujuan informasi ataupun tujuan persuasi yaitu mempengaruhi perilaku).</p>-->
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Selengkapnya</a>
            </div>
          </div>
        </div>

        <!-- Slide 5 -->
        <div class="carousel-item" style="background-image: url(assets/aset/baner/baner3.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Sistem Informatika dan Jaringan Aplikasi</h2>
              <!--<p class="animate__animated animate__fadeInUp text-truncate">Sistem Informatika dan Jaringan Aplikasi (SIJA) merupakan kompetensi keahlian baru berbasis Teknologi Informasi dan Komunikasi pada program keahlian Teknik Komputer dan Informatika yang mulai dibuka pada Tahun Pelajaran 2017/2018 untuk program pendidikan SMK dengan pembelajaran Empat (4) Tahun. Sesuai dengan Keputusan Dirjen Dikdasmen Kemendikbud Nomor: 4678/D/KEP/MK/2016.-->
              <!--  SIJA merupakan pembelajaran di SMK selama 4 tahun yang terbagi menjadi dua 2 model belajar, yaitu belajar di sekolah selama 3 tahun dan belajar di industry selama 1 tahun</p>-->
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">selengkapnya</a>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

        <!-- ======= Icon Boxes Section ======= -->
        <section id="icon-boxes" class="icon-boxes">
          <div class="container">
    
            <div class="row g-3 text-center">
              <div class="col-6 col-lg-3 d-flex align-items-stretch mb-1 mb-lg-0 " data-aos="fade-up">
                <div class="icon-box prf">
                  <!-- <div class="icon"><i class="bx bxl-dribbble"></i></div> -->
                  <div class="icon"><img src="assets/aset/profil.png" class="img-fluid" alt=""></div>
                  <h4 class="title"><a href="#">PROFIL</a></h4>
                  <p class="description lh-base">Tentang SMK BUDI MULIA</p>
                </div>
              </div>
    
              <div class="col-6 col-lg-3 d-flex align-items-stretch mb-1 mb-lg-0" data-aos="fade-up">
                <a href="https://smkbudimuliapakisaji.sch.id/ppdb"><div class="icon-box">
                  <!-- <div class="icon"><i class="bx bx-file"></i></div> -->
                  <div class="icon"><img src="assets/aset/ppdb.png" class="img-fluid" alt=""></div>
                  <h4 class="title"><a href="https://smkbudimuliapakisaji.sch.id/ppdb">PPDB</a></h4>
                  <p class="description lh-base">Informasi pendaftaran peserta didik baru</p>
                </div></a>
              </div>
    
              <div class="col-6 col-lg-3 d-flex align-items-stretch mb-1 mb-lg-0" data-aos="fade-up">
                <div class="icon-box">
                  <!-- <div class="icon"><i class="bx bx-tachometer"></i></div> -->
                  <div class="icon"><img src="assets/aset/dudi.png" class="img-fluid" alt=""></div>
                  <h4 class="title"><a href="#">DUDI</a></h4>
                  <p class="description lh-base">Informasi terkait mitra dunia usaha dan dunia industri</p>
                </div>
              </div>
    
              <div class="col-6 col-lg-3 d-flex align-items-stretch mb-1 mb-lg-0" data-aos="fade-up">
                <div class="icon-box">
                  <!-- <div class="icon"><i class="bx bx-layer"></i></div> -->
                  <div class="icon"><img src="assets/aset/lulusan.png" class="img-fluid" alt=""></div>
                  <h4 class="title"><a href="#">LULUSAN</a></h4>
                  <p class="description lh-base">Informasi terkait lulusan dan alumni SMK Budi Mulia</p>
                </div>
              </div>
    
            </div>
    
          </div>
        </section>
        <!-- End Icon Boxes Section -->
    
        <!-- ======= Why Us Section ======= -->
        <section id="why-us" class="sambutan">
          <div class="container" data-aos="fade-up">

            <div class="row justify-content-center">
              <div class="col-lg-6 col-12 d-flex flex-column justify-content-center align-items-stretch order-2 order-lg-1">
      
                <div class="content">
                  <p class="fs-5 fw-bold text-muted">Selamat Datang di Website SMK Budi Mulia Pakisaji</p>
                  <!--<h3>Drs. Suyono M.T</h3>-->
                  
                  <!-- <h3><strong>Drs. Suyono M.T</strong></h3> -->
                  <p>
                    Di website SMK Budi Mulia Pakisaji yang saya tujukan untuk seluruh unsur pimpinan, guru, karyawan dan siswa serta khalayak umum guna dapat mengakses seluruh informasi tentang sekolah kami. Tentunya dalam penyajian informasi masih banyak kekurangan, oleh karena itu kepada seluruh civitas akademika dan masyarakat umum dapat memberikan saran dan kritik demi kemajuan lebih lanjut.
                  </p>
                  
                </div>
                
              </div>
                <!-- style='background-image: url("assets/aset/ks1.png");' -->
              <div class="col-lg-6 col-12 align-items-stretch video-box order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="100">
                <!-- <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a> -->
                <img src="assets/aset/gmbr1.webp" alt="" class="img-fluid">
              </div>

            </div>
          </div>
        </section>
    <!-- End Why Us Section -->

    <!--  -->
    <section id="pamflet" class="section-bg">
      <div class="section-title text-center">
        <p>Informasi Terkini</p>
      </div>
        <!-- <div class="text-center">
          <h2>Informasi Utama</h2>
        </div> -->
        <div class="owl-carousel owl-theme">
          <div class="item sleder">
            <img src="https://i.ytimg.com/vi/PbkyO3s4rq8/maxresdefault.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://cdn0-production-images-kly.akamaized.net/H6L4O1_ZXCKXd-una1qdb9tuQfU=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3238805/original/026721700_1600167696-Generasi_Micin_Poster_-_Landscape.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://t-2.tstatic.net/jogja/foto/bank/images/poster-film-Lara-Ati.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://cdn1-production-images-kly.akamaized.net/OOGtt-P15LIoBgkZfBNlZK8DFCc=/1231x710/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3540361/original/096652500_1628944459-Hari_Ini_Pasti_Menang2_-_Landscape.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://ik.imagekit.io/tk6ir0e7mng/uploads/2022/08/1661585565369.jpeg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://www.dictio.id/uploads/db3342/optimized/3X/f/1/f1b911ab33da226839532195bb2d7e9800850260_2_1024x575.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://mmc.tirto.id/image/otf/500x0/2020/07/16/gambar-1-landscape---guru-guru-gokil-tayang-di-netflix-bagi-penonton-global-15-juli-2020_ratio-16x9.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://cdn0-production-images-kly.akamaized.net/acnVF2NQ3CvmElqevNBhGlzdSJE=/1200x675/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3585742/original/064893600_1632814211-Keluarga_Cemara_Cover_Landscape.jpg" class="sleder1" alt="">
          </div>
          <div class="item sleder">
            <img src="https://about.vidio.com/wp-content/uploads/2022/01/Mau-Jadi-Apa-Poster-Landscape.jpg" class="sleder1" alt="">
          </div>
        </div>
      
    </section>
    <!--  -->

    <!-- berita -->
        <section id="beritabm" class="beritabm">
          <div class="container">
            <div class="section-title">
              <h2>SMK Budi Mulia</h2>
              <p>Berita Terkini</p>
            </div>
            <!-- <div class="text text-center">
              <h2 style="margin-top: 5px;">Berita BM</h2>
            </div> -->
            <div class="row g-0">
              <div class="col-md-4 order-1 order-lg-1 order-md-1 mt-3 mb-2">
                <div class="card brd">
                  <div class="card-body crd">
                    <h4 class="text-center text-decoration-underline">Berita</h4>
                    <ul class="" style="list-style: none;">
                      <li>
                        <p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">12 Desember, 2022</p>
                        <a href="hariguru" class="fs-6 text-dark">Bahagia dan penuh haru SMK Merayakan Hari guru.</a>
                      </li>
                      <!--<li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>-->
                      <!--  <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>-->
                      <!--<li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>-->
                      <!--  <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>-->
                      <!--<li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>-->
                      <!--  <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>-->
                      <!--<li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>-->
                      <!--  <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>-->
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-4 order-3 order-lg-2 order-md-2 mt-3 ">
                <div class="card border-0">
                  <div class="card-body crd text-light" style="background-color: #003366;">
                    <h4 class="text-center text-decoration-underline">Prestasi</h4>
                    <ul class="" style="list-style: none;">
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-white">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-white">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-white">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-white">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-white">Lorem ipsum dolor sit amet.</a></li>
                    </ul>
                    <!-- lancip -->
                    
                    <!-- <span class="lancip2"></span> -->
                    <!--  -->
                  </div><span class="lancip1"></span>
                </div>
              </div>
              <div class="col-md-4 order-2 order-lg-3 order-md-3 mt-3 mb-2">
                <div class="card brd">
                  <div class="card-body crd">
                    <h4 class="text-center text-decoration-underline">Pengumuman</h4>
                    <ul class="" style="list-style: none;">
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>
                      <li><p class="text-muted" style="font-size: 12px; margin-bottom: -4px;">OCTOBER 10, 2022</p>
                        <a href="" class="fs-5 text-dark">Lorem ipsum dolor sit amet.</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- akhir berita -->

    <!-- ======= Cta Section ======= -->

    <section id="cta" class="cta ">
      <div class="container" data-aos="zoom-in">
        <div class="text-center pt-4">
          <p class="text-white fs-2 fw-bold">Total Keseluruhan</p>
          <div class="row counters">

            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="82" data-purecounter-duration="2" class="purecounter"></span>
              <p>Guru</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="421" data-purecounter-duration="2" class="purecounter"></span>
              <p>Siswa</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="11" data-purecounter-duration="2" class="purecounter"></span>
              <p>Extra</p>
            </div>
  
            <div class="col-lg-3 col-6 text-center">
              <span data-purecounter-start="0" data-purecounter-end="12258" data-purecounter-duration="2" class="purecounter"></span>
              <p>Alumni</p>
            </div>
  
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= jurusan Section ======= -->
    <section id="jurusan" class="portfolio mb-5" data-aos="fade-up">

          <div class="container">
            <div class="section-title">
              <h2>SMK Budi Mulia</h2>
              <p>Berita Jurusan</p>
            </div>
            <!-- <div class="text-center py-4">
              <h2>Bilik Jurusan</h2>
            </div> -->
          </div>
    
          <div class="container" data-aos="fade-up" data-aos-delay="200">
    
            <div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry" data-portfolio-sort="original-order">
    
              <ul class="portfolio-flters">
                <li data-filter="*" class="filter-active">Semua</li>
                <li data-filter=".filter-tkj">TKJ</li>
                <li data-filter=".filter-dkv">DKV</li>
                <li data-filter=".filter-bdp">BDP</li>
                <li data-filter=".filter-sija">SIJA</li>
              </ul><!-- End Portfolio Filters -->
    
              <div class="row g-0 portfolio-container ">
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-tkj">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1617713430783-eea916372c5b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1374&q=80" class="gmbr1" alt="...">
                  </div>
                  <a href=""><div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p>TKJ | 3 mei 2022 - 16:45</p>
                  </div></a>
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-dkv">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1619973816097-3ea70ce0fc28?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Zm90b2dyYWZlcnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p class="">DKV | 4 april 2022 - 13:45</p>
                  </div>
    
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-bdp">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Zm9vZHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p class="">BD | 5 Juni 2022 - 10:09</p>
                  </div>
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-sija">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1527612820672-5b56351f7346?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p>SIJA | 6 Agustus 2022 - 18:00</p>
                  </div>
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-tkj">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDN8fHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p class="">TKJ | 3 mei 2022 - 16:45</p>
                  </div>
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-dkv">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1619973816097-3ea70ce0fc28?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Zm90b2dyYWZlcnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p class="">DKV | 4 april 2022 - 13:45</p>
                  </div>
    
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-bdp">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Zm9vZHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p class="">BD | 5 Juni 2022 - 10:09</p>
                  </div>
                </div><!-- End Portfolio Item -->
    
                <div class="col-xl-3 col-lg-4 col-6 portfolio-item rounded filter-sija">
                  <div class="gmbr">
                    <img src="https://images.unsplash.com/photo-1527612820672-5b56351f7346?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80" class="gmbr1" alt="...">
                  </div>
                  <div class="portfolio-info">
                    <h4>Lorem ipsum dolor sit amet.</h4>
                    <p>SIJA | 6 Agustus 2022 - 18:00</p>
                  </div>
                </div><!-- End Portfolio Item -->
    
              </div><!-- End Portfolio Container -->
    
            </div>
    
          </div>
    </section>
    <!-- End Portfolio Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>SMK Budi Mulia</h2>
          <p>Guru & Staff</p>
        </div>

        <div class="test swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <!-- <div class="col-xl-3 col-lg-4 col-md-6"> -->
              <div class="swiper-slide">
                <div class="member rounded" data-aos="zoom-in" data-aos-delay="100">
                  <img src="assets/aset/clients/ks2.jpg" class="img-fluid" alt="">
                  <div class="member-info">
                    <div class="member-info-content">
                      <h4>Drs. Suyono M.T</h4>
                      <span>Kepala Sekolah SMK BM</span>
                    </div>
                    <div class="social">
                      <a href=""><i class="bi bi-twitter"></i></a>
                      <a href=""><i class="bi bi-facebook"></i></a>
                      <a href=""><i class="bi bi-instagram"></i></a>
                      <a href=""><i class="bi bi-linkedin"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            <!-- </div> -->

            <!-- <div class="col-xl-3 col-lg-4 col-md-6" data-wow-delay="0.1s"> -->
              <div class="swiper-slide">
              <div class="member rounded" data-aos="zoom-in" data-aos-delay="200">
                <img src="assets/aset/clients/wks.jpg" class="img-fluid" alt="">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>Agus Susanto Spd</h4>
                    <span>Wakil Kepala Sekolah SMK BM</span>
                  </div>
                  <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
              </div>
            <!-- </div> -->

            <!-- <div class="col-xl-3 col-lg-4 col-md-6" data-wow-delay="0.2s"> -->
              <div class="swiper-slide">
              <div class="member rounded" data-aos="zoom-in" data-aos-delay="300">
                <img src="assets/aset/clients/kuri.jpg" class="img-fluid" alt="">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>Asroriati Spd</h4>
                    <span>Kurikulum SMK BM</span>
                  </div>
                  <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
              </div>
            <!-- </div> -->

            <!-- <div class="col-xl-3 col-lg-4 col-md-6" data-wow-delay="0.3s"> -->
            <div class="swiper-slide">
              <div class="member rounded" data-aos="zoom-in" data-aos-delay="400">
                <img src="assets/aset/clients/kesiswaan.jpg" class="img-fluid" alt="">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>Agung Prasetyo S.Kom</h4>
                    <span>Kesiswaan SMK BM</span>
                  </div>
                  <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- </div> -->

            <div class="swiper-slide">
              <div class="member rounded" data-aos="zoom-in" data-aos-delay="200">
                <img src="assets/aset/clients/bndrr.jpg" class="img-fluid" alt="">
                <div class="member-info">
                  <div class="member-info-content">
                    <h4>Imam Budiono</h4>
                    <span>Bendahara SMK BM</span>
                  </div>
                  <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
              </div>

          </div>
          <!-- <div class="swiper-paginations"></div> -->
        </div>
        
      </div>
    </section><!-- End Team Section -->

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container">
        <!-- <div class="section-title">
          <h2>SMK Budi Mulia</h2>
          <p>Supported</p>
        </div> -->
        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><img src="assets/aset/clients/bdp1.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/aset/clients/bmmert.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/aset/clients/bmnet.jpeg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/aset/clients/bmpd.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/aset/clients/sija.jpeg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/aset/clients/tkj(4).png" class="img-fluid" alt=""></div>
          </div>
        </div>

      </div>
    </section><!-- End Clients Section -->
  </main>
  <!-- End #main -->
@endsection
