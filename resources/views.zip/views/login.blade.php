@extends('Layout.layout4')
@section('title', 'Artikel')
@section('content')

<button id="google-signin-button" class="mt-5">Sign in with Google</button>





<!-- Include the Firebase library -->
<script src="https://www.gstatic.com/firebasejs/7.18.0/firebase-app.js"></script>
<!-- Include the Google Sign-In library -->
<script src="https://www.gstatic.com/firebasejs/7.18.0/firebase-auth.js"></script>

<script>
// Get the sign-in button
var googleSigninButton = document.getElementById("google-signin-button");

// Add event listener for the sign-in button
googleSigninButton.addEventListener("click", function() {
  // Sign in with Google
  var provider = new firebase.auth.GoogleAuthProvider();
  firebase.auth().signInWithPopup(provider).then(function(result) {
    // User is signed in
    var user = result.user;
    console.log(user);
  }).catch(function(error) {
    // An error occurred
    console.error(error);
  });
});
</script>
@endsection