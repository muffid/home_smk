@extends('Layout.layout')
@section('title', 'Guru')
@section('content')

<div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/aset/baner/img1.jpg');">
    <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

      <h2>Guru</h2>
      <ol>
        <li><a href="/">Home</a></li>
        <li>Guru</li>
      </ol>

    </div>
</div><!-- End Breadcrumbs -->

<!-- ======= Trainers Section ======= -->
<section id="trainers" class="trainers">
    <div class="container" data-aos="fade-up">

      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
          <div class="member">
            <img src="assets/aset/clients/ks2.jpg" class="img-fluid" alt="">
            <div class="member-content">
                <h4>Drs. Suyono M.T</h4>
                <span>Kepala Sekolah SMK BM</span>
              <p>
                Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut
              </p>
              <a href="guru2">selengkapnya >>></a>
              <div class="social">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
          <div class="member">
            <img src="assets/aset/clients/wks.jpg" class="img-fluid" alt="">
            <div class="member-content">
                <h4>Agus Susanto Spd</h4>
                <span>Wakil Kepala Sekolah SMK BM</span>
              <p>
                Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto rerum rerum temporibus
              </p>
              <div class="social">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
          <div class="member">
            <img src="assets/aset/clients/bndrr.jpg" class="img-fluid" alt="">
            <div class="member-content">
              <h4>William Anderson</h4>
              <span>Content</span>
              <p>
                Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et laborum toro des clara
              </p>
              <div class="social">
                <a href=""><i class="bi bi-twitter"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/aset/clients/bndrr.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4>William Anderson</h4>
                <span>Content</span>
                <p>
                  Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et laborum toro des clara
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/aset/clients/ks2.jpg" class="img-fluid" alt="">
              <div class="member-content">
                  <h4>Drs. Suyono M.T</h4>
                  <span>Kepala Sekolah SMK BM</span>
                <p>
                  Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis perspiciatis quaerat qui aut aut aut
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
  
          <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/aset/clients/wks.jpg" class="img-fluid" alt="">
              <div class="member-content">
                  <h4>Agus Susanto Spd</h4>
                  <span>Wakil Kepala Sekolah SMK BM</span>
                <p>
                  Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto rerum rerum temporibus
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
  
          <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/aset/clients/bndrr.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4>William Anderson</h4>
                <span>Content</span>
                <p>
                  Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et laborum toro des clara
                </p>
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>
  
          <div class="col-6 col-lg-3 col-md-4 d-flex align-items-stretch">
              <div class="member">
                <img src="assets/aset/clients/bndrr.jpg" class="img-fluid" alt="">
                <div class="member-content">
                  <h4>William Anderson</h4>
                  <span>Content</span>
                  <p>
                    Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et laborum toro des clara
                  </p>
                  <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>

      </div>

    </div>
  </section><!-- End Trainers Section -->

@endsection