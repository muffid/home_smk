<?php

namespace Illuminate\Database\Events;

class MigrationStarted extends MigrationEvent
{
    //
}
