@extends('Layout.layout')
@section('title', 'Detail Guru')
@section('content')
<div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/aset/baner/img1.jpg');">
    <div class="container position-relative d-flex flex-column align-items-center" data-aos="fade">

      <h2>Profil Guru</h2>
      {{-- <ol>
        <li><a href="/">Home</a></li>
        <li><a href="guru">Guru</a></li>
        <li>Detail Guru</li>
      </ol> --}}

    </div>
</div><!-- End Breadcrumbs -->
<div class="container">
<div class="row justify-content-evenly">

    <div class="col-12 col-lg-3">
        <section class="page2">
            <div class="member">
                <img src="assets/aset/clients/ks2.jpg" class="img-fluid rounded-circle" alt="">
                <div class="member-content">
                    <h4>Drs. Suyono M.T</h4>
                    <span>Kepala Sekolah SMK BM</span>
                <div class="social">
                    <a href=""><i class="bi bi-twitter"></i></a>
                    <a href=""><i class="bi bi-facebook"></i></a>
                    <a href=""><i class="bi bi-instagram"></i></a>
                    <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
                </div>
            </div>
        </section>
    </div>
    <div class="col-12 col-lg-7 mt-5">
        <section class="p-2">
            <h4>Drs. Suyono M.T</h4>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum officiis rerum debitis accusantium hic magnam, nulla laboriosam, sapiente exercitationem facere possimus blanditiis culpa accusamus nobis, odit aliquid corporis fugit eveniet enim vero ipsam tempore! Nostrum animi beatae ea eum voluptatum labore iste numquam error maxime.</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum officiis rerum debitis accusantium hic magnam, nulla laboriosam, sapiente exercitationem facere possimus blanditiis culpa accusamus nobis, odit aliquid corporis fugit eveniet enim vero ipsam tempore! Nostrum animi beatae ea eum voluptatum labore iste numquam error maxime.</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum officiis rerum debitis accusantium hic magnam, nulla laboriosam, sapiente exercitationem facere possimus blanditiis culpa accusamus nobis, odit aliquid corporis fugit eveniet enim vero ipsam tempore! Nostrum animi beatae ea eum voluptatum labore iste numquam error maxime.</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum officiis rerum debitis accusantium hic magnam, nulla laboriosam, sapiente exercitationem facere possimus blanditiis culpa accusamus nobis, odit aliquid corporis fugit eveniet enim vero ipsam tempore! Nostrum animi beatae ea eum voluptatum labore iste numquam error maxime.</p>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum officiis rerum debitis accusantium hic magnam, nulla laboriosam, sapiente exercitationem facere possimus blanditiis culpa accusamus nobis, odit aliquid corporis fugit eveniet enim vero ipsam tempore! Nostrum animi beatae ea eum voluptatum labore iste numquam error maxime.</p>
        </section>
    </div>
  </div>
</div>
@endsection