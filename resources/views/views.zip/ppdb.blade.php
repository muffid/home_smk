@extends('layout.layout')
@section('title', 'Profil SMK Budi Mulia Pakisaji')
@section('content')
<h2>ppdb</h2>
@endsection